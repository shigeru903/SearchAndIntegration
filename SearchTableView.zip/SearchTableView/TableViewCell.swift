

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var imageUrl:        UIImageView!
    
    @IBOutlet weak var nameLabel:       UILabel!
    
    @IBOutlet weak var descLabel:       UILabel!
    
    @IBOutlet weak var button:          UIButton!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        print("Generic Cell Initialization Done")
    }
        
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.button.layer.borderWidth = 2
        self.button.layer.borderColor = UIColor(red: 58.0/255.0, green: 108.0/255.0, blue: 219.0/255.0, alpha: 1.0).CGColor
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}