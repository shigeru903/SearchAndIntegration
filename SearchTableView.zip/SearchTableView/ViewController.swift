

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    
    @IBOutlet weak var searchBar:   UISearchBar!
    @IBOutlet weak var tableView:   UITableView!
    
    @IBOutlet weak var VXWL_pre:    UILabel!
    @IBOutlet weak var VXWL:        UILabel!
    @IBOutlet weak var User_pre:    UILabel!
    @IBOutlet weak var User:        UILabel!
    
    var items =                     NSMutableArray()
    
    var searchActive :              Bool = false
    var tabBtn :                    Bool = false
    
    var picUrl:                     [String] = []
    var name:                       [String] = []
    var desc:                       [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Setup delegates */
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        
        // Initialize
        self.searchBar.delegate = self
        let textFieldInsideSearchBar = searchBar.valueForKey("searchField") as? UITextField
        textFieldInsideSearchBar?.textColor = UIColor.whiteColor()
        self.searchBar.setImage(UIImage(named: "cancel.png"), forSearchBarIcon: UISearchBarIcon.Clear, state: UIControlState.Normal)
        self.searchBar.setImage(UIImage(named: "glass.png"), forSearchBarIcon: UISearchBarIcon.Search, state: UIControlState.Normal)
        
        textFieldInsideSearchBar!.font = UIFont(name: "Header", size: 16.0)!
        
        textFieldInsideSearchBar?.backgroundColor = UIColor(red: 43.0/255/0, green: 76.0/255.0, blue: 160.0/255.0, alpha: 1.0)
        /*
        for view in self.searchBar.subviews {
            for subview in view.subviews {
                if subview .isKindOfClass(UITextField) {
                    let textField: UITextField = subview as! UITextField
                    textField.backgroundColor = UIColor.lightGrayColor()
                }
            }
        }
        */
        
        // Search bar placeholder' letters
        for subView in self.searchBar.subviews
        {
            for subsubView in subView.subviews
            {
                if let textField = subsubView as? UITextField
                {
                    textField.attributedPlaceholder = NSAttributedString(string: NSLocalizedString("Search", comment: ""), attributes: [NSForegroundColorAttributeName: UIColor.whiteColor()])
                }
            }
        }
        
        VXWL.text = "VXWL(0)"
        User.text = "User(0)"
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchActive = true
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchActive = false
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchActive = false
    }

    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        
        // Enter search word and Request
        picUrl = []
        name = []
        desc = []
        dispatch_async(dispatch_get_main_queue(), {
            self.tableView.reloadData()
        })
        
        addDummyData( searchBar.text! )
        searchActive = true
        
        self.view.endEditing(true)
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        searchActive = false;
    }
    
    func searchBarShouldEndEditing(searchBar: UISearchBar) -> Bool {
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return picUrl.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as! TableViewCell
        
        // revert imageView's shape
        if self.tabBtn {
            cell.imageUrl.layer.cornerRadius = cell.imageUrl.frame.size.width / 2
            cell.imageUrl.clipsToBounds = true
        }
        else {
            cell.imageUrl.clipsToBounds = false
        }
        
        if picUrl[indexPath.row] != "" {
            let url = NSURL(string: picUrl[indexPath.row])
            let data = NSData(contentsOfURL: url!)
            cell.imageUrl.image = UIImage(data: data!)
        }
        if name[indexPath.row] != "" {
            cell.nameLabel.text = name[indexPath.row]
        }
        if desc[indexPath.row] != "" {
            cell.descLabel.text = desc[indexPath.row]
        }
        
        return cell
    }
    
    @IBAction func VXWL_clk(sender: UIButton) {
        
        searchBar.text = ""
        self.tabBtn = false
        VXWL.textColor = UIColor(red: 58.0/255.0, green: 108.0/255.0, blue: 219.0/255.0, alpha: 1.0)
        User.textColor = UIColor.blackColor()
        VXWL_pre.hidden = true
        User_pre.hidden = false
        picUrl = []
        name = []
        desc = []
        VXWL.text = "VXWL(0)"
        self.tableView.reloadData()
    }
    
    @IBAction func User_clk(sender: UIButton) {
        
        searchBar.text = ""
        self.tabBtn = true
        VXWL.textColor = UIColor.blackColor()
        User.textColor = UIColor(red: 58.0/255.0, green: 108.0/255.0, blue: 219.0/255.0, alpha: 1.0)
        VXWL_pre.hidden = false
        User_pre.hidden = true
        picUrl = []
        name = []
        desc = []
        User.text = "User(0)"
        self.tableView.reloadData()
    }
    
    // request and parse json
    func addDummyData(param: String) {
        
        //request with keyword
        APIProxy.sharedInstance.getData(param, onCompletion: { json -> Void in
            var searched_data:JSON
            var count:Int = 0
            
            //start if
            if !self.tabBtn {
                searched_data = json["data"]["voxwells"]
                if searched_data == nil {
                    return
                }
                for index in 0..<searched_data.count {
                    if let _picUrl = searched_data[index]["pict150"].string {
                        self.picUrl.append(_picUrl)
                    } else {
                        self.picUrl.append("")
                    }
                    
                    if let _name = searched_data[index]["name"].string {
                        self.name.append(_name)
                    } else {
                        self.name.append("")
                    }
                    
                    if let _desc = searched_data[index]["street"].string {
                        self.desc.append(_desc)
                    } else {
                        self.desc.append("")
                    }
                }
                dispatch_async(dispatch_get_main_queue(), {
                    count = searched_data.count
                    self.VXWL.text = "VXWL(" + String(count) + ")"
                    self.tableView.reloadData()
                })
            }
            else {
                searched_data = json["data"]["users"]
                if searched_data == nil {
                    return
                }
                for index in 0..<searched_data.count {
                    if let _picture_small = searched_data[index]["picture_small"].string {
                        self.picUrl.append(_picture_small)
                    } else {
                        self.picUrl.append("")
                    }
                    
                    if let _first_name = searched_data[index]["first_name"].string , let _last_name = searched_data[index]["last_name"].string {
                        self.name.append(_first_name + " " + _last_name)
                    } else {
                        self.name.append("")
                    }
                    
                    if let _gender = searched_data[index]["gender"].string {
                        self.desc.append(_gender)
                    } else {
                        self.desc.append("")
                    }
                }
                dispatch_async(dispatch_get_main_queue(), {
                    self.tableView.reloadData()
                    count = searched_data.count
                    self.User.text = "User(" + String(count) + ")"
                })
            }
            //end if
        })
        //end request.
    }
    //end json parse
}

